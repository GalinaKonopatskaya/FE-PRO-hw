let carsStore = {
  sport: {
    items: [
      { name: "Honda S2000", price: 10000, },
      { name: "BMW M5", price: 50000 },
    ]
  },
  luxury: {
    items: [
      { name: "Mercedes S600", price: 80000 },
      { name: "Range Rover", price: 90000, },
    ]
  },
  offRoad: {
    items: [
      { name: "Nissan Patrol", price: 45000 },
      { name: "Jeep Wrangler", price: 20000 },
    ]
  }
}

let categories = {
  1: "sport",
  2: "luxury",
  3: "offRoad"
}
