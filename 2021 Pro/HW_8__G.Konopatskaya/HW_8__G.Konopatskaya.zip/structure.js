let person = {
    firstName: "Boris",
    lastName: "Britva",
    gender: "male", 
    born: 1995,
}


let person2 = {
    firstName: "Vika",
    lastName: "Ciganova",
    gender: "female", 
    born: 1999,
}


let person3 = {
    firstName: "Rachel",
    lastName: "Brinson",
    gender: "female", 
    born: 1983,
}


let person4 = {
    firstName: "Luke",
    gender: "male", 
    born: 1971,
}


let person5 = {
    firstName: "Robin",
    lastName: "Good",
    gender: "male", 
    born: 2006,
}