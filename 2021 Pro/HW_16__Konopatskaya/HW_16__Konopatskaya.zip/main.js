// Задана цепочка вызовов.
// greeting().then(f1).then(f2).then(f3);
// Вам нужно написать реализацию даннлой конструкции, 
// чтоб её вызов вывел на экран фразу
// Hello, I have realised how promises work!
// При этом:
// Слово "Hello" должно появится на экране сразу после вызова данной конструкции, 
// а все остальные слова по очереди, с переодичностью не раньше чем 1 секунда.

const container = document.getElementById("container");

function greeting(ms) {
	container.insertAdjacentHTML("beforeend", '<span>Hello, </span>');
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			resolve()
		}, ms)

	})
}

function f1() {
	container.insertAdjacentHTML("beforeend", '<span>I have realised</span>');


}

function f2() {
	setTimeout(() => {
		container.insertAdjacentHTML("beforeend", '<span> how promises </span>');
	}, 1000)
}

function f3() {
	setTimeout(() => {
		container.insertAdjacentHTML("beforeend", '<span> work! </span>');
	}, 2000)
}

greeting(1000).then(f1).then(f2).then(f3);

