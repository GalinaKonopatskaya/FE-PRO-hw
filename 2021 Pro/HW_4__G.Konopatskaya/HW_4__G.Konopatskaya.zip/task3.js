//Вывести таблицу умножения на 5
console.log(`Таблица умножения на 5 `)
let five = 5;

for (let a = 1; a <= 10; a++) {
    console.log(`${ five } * ${ a } = ${ five * a}`);

}



