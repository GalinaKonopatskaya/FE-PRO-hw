//--------------- 1 ------------------------------
// class Car {
//     constructor(name) {
//         this.name = name;
        
//     }
//     fullTank(quantity) {
//        let quant = `with ${quantity}L`
//     }

//     toColor(color) {
//         let col = `You are driving ${color}`
//        // color = color;
//     }
//     go() {
//         console.log(`${this.col} ${this.name} ${quant} of fuel.`)
//     }

//     // ... implementation
// }

// let honda = new Car("Honda");

// honda.fullTank(25).toColor("red").go()
// //Result:  You are driving red Honda with 25L of fuel.


//--------------- 2 ------------------------------
const INFO_CONTENT = "<p class='info'> Some info content </p>";
const DATA_CONTENT = "<p class='data'> Some data about product </p>";


const infoBtn = document.getElementById("info");
const dataBtn = document.getElementById("data");
const contentContainer = document.querySelector(".content");


infoBtn.addEventListener('click', addInfo);
dataBtn.addEventListener('click', addData);



function addInfo() {
    let inner = INFO_CONTENT;
    infoBtn.style.backgroundColor = "green";
    dataBtn.style.backgroundColor = "";
    contentContainer.insertAdjacentHTML("beforeend", inner);
}


function addData() {
    let data = DATA_CONTENT;
    dataBtn.style.backgroundColor = "red";
    infoBtn.style.backgroundColor = "";

    contentContainer.insertAdjacentHTML("beforeend", data);
}
