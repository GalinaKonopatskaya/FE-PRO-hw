let organization = {
  ceo: {
    name: "Josh",
    emploies: [
      { name: "Robert" },
      { name: "Diana" },
      {
        name: "Taylor",
        emploies: [
          { name: "Ruslan" },
          { name: "Valeriy" },
          { name: "Taras" },
        ]
      }
    ]
  },
  cto: {
    name: "Pablo",
    emploies: [
      { name: "Vuu" },
      { name: "Zibert" },
      {
        name: "Trash",
        emploies: [
          { name: "Konstantin" },
          { name: "Dan-Balan" },
          { name: "Luk" },
        ]
      }
    ]
  },
  rnd: {
    name: "Irakliy"
  }
}
