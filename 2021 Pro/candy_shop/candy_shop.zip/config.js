module.exports = {
    PORT: 3000,
    //MONGO_URL: 'mongodb://localhost/blog'
  };