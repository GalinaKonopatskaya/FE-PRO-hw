const fs = require('fs');
const testFs = require('fs').promises;


class Model {






}



module.exports = {
 
    Model
  
  };