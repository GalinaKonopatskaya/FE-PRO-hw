class Product {

   
  constructor(id, name, url, cost, qty, group, info) {
    this.id = id
    this.name = name;
    this.url = url;
    this.cost = cost;
    this.qty = qty;
    this.group = group
    this.info = info
  }

  static testfunction(){
    console.log("test product");
    console.logt();
  }





}


module.exports = {
 
  Product

};