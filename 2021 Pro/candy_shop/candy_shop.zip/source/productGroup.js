class ProductGroup {

    constructor(id, groupName, groupInfo){
       this.id = id
       this.groupName = groupName;
       this.groupInfo = groupInfo;
    }

    static testfuction(){
        console.log("test group")
    }
  
  
}


module.exports = {
 
    ProductGroup
  
};