const users = [
	{
		id: 01,
		name: "Leonardo",
		surname: "",
		age: 14,
		depositAmount: 15000,
		car: "",
	},
	{
		id: 02,
		name: "April",
		surname: "O'Neil",
		age: 25,
		depositAmount: 25000,
		car: "",
	},
	{
		id: 03,
		name: "Hamato",
		surname: "Yoshi",
		age: 36,
		depositAmount: 35000,
		car: "",
	},
	{
		id: 04,
		name: "Oroku",
		surname: "Saki",
		age: 34,
		depositAmount: 55000,
		car: "",
	}
];

const cars = [
	{
		id: 01,
		make: "Toyota",
		model: "Corolla",
		price: 18000,
		owner: "",
	},
	{
		id: 02,
		make: "Toyota",
		model: "Supra",
		price: 15000,
		owner: "",
	},
	{
		id: 03,
		make: "Toyota",
		model: "Prius",
		price: 20000,
		owner: "",
	},
	{
		id: 04,
		make: "Toyota",
		model: "Highlander",
		price: 25000,
		owner: "",
	}
];



