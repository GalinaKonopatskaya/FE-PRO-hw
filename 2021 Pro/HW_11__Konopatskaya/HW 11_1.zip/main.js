const productForm = document.forms['productForm'];


const catSelect = document.querySelector("#category");
const itemsSelect = document.querySelector("#items");
const attributesDiv = document.querySelector("#attributes");
const submitOrder = document.querySelector("#submit");


// -----  for POPUP 
const popupLink = document.querySelector('.popup-link');

const body = document.querySelector('body');

let unlock = true;

const timeout = 800;


//--------

createSelectOptions(catSelect, product);


function createAttrList(target, attrObj) {
	target.innerHTML = "";
	let htmlText = "";
	for (let key in attrObj) {

		htmlText += `<div><b>${attrObj[key].name}</b>
				<ul  class="attributes" 
					data-attribute="${attrObj[key].codeName}" >`;

		for (let k in attrObj[key].values) {
			htmlText += `<li><input type = "radio" 
						value="${attrObj[key].values[k]}"
						name = "attribute_${attrObj[key].codeName}"
			>&nbsp;${attrObj[key].values[k]} ${attrObj[key].unit} </li>`;
		}

		htmlText += "</ul></div>";

	}
	target.insertAdjacentHTML("beforeend", htmlText);
}

function createSelectOptions(target, obj) {
	const option = document.createElement("option");
	target.innerHTML = "";
	option.value = "";
	option.text = "Выберите категорию..";
	target.add(option);

	for (var key in obj) {
		const option = document.createElement("option");
                option.value = key;
		if (typeof obj[key].name != 'undefined') {
			option.text = obj[key].name;
		}
		else {
			option.text = obj[key];
		}

		target.add(option);
	}

	
}


/******ENENT LISTENERS*********/

catSelect.addEventListener("change", function (el) {
	let key = this.value;
	createSelectOptions(itemsSelect, product[key].models);
	createAttrList(attributesDiv, product[key].attrList);
});

itemsSelect.addEventListener("change", function (el) {
	let key = this.value;
});

const category = document.g;

console.dir(category);

// submitOrder.addEventListener("click", function (el) {
// 	//el.preventDefault();

// 	const category = productForm.elemtnts.select.value;

// 	console.dir(category);

// 	// let categoryId = catSelect.value;
// 	// let itemId = itemsSelect.value;
// 	// let attributesList = attributesDiv.querySelectorAll('input[name="attribute_' + itemId + '"]');
// 	// for (let attr in attributesList) {
// 	// 	console.log(attr.value);
// 	// }
// 	// console.log('categoryId:' + categoryId);

// });



//---------- POPUP---------

popupLink.addEventListener("click", function (e) {
	const popupName = popupLink.getAttribute('href').replace('#', '');
	const curentPopup = document.getElementById(popupName);
	popupOpen(curentPopup);
	e.preventDefault();
});


const popupCloseIcon = document.querySelectorAll('.close-popup');
if (popupCloseIcon.length > 0) {
	for (let index = 0; index < popupCloseIcon.length; index++) {
		const el = popupCloseIcon[index];
		el.addEventListener('click', function (e) {
			popupClose(el.closest('.popup'));
			e.preventDefault();
		});
	}
}

function popupOpen(curentPopup) {
	if (curentPopup && unlock) {
		const popupActive = document.querySelector('.popup.open');
		if (popupActive) {
			popupClose(popupActive, false);
		} else {
			bodyLock();
		}
		curentPopup.classList.add('open');
		curentPopup.addEventListener('click', function (e) {
			if (!e.target.closest('.popup__content')) {
				popupClose(e.target.closest('.popup'));
			}
		});
	}
}

function popupClose(popupActive, doUnlock = true) {
	if (unlock) {
		popupActive.classList.remove('open');
		if (doUnlock) {
			bodyUnLock();
		}
	}
}

function bodyLock() {
	unlock = false;
	setTimeout(function () {
		unlock = true;
	}, timeout);


}

function bodyUnLock() {
	setTimeout(function () {
		body.classList.remove('lock');
	}, timeout);
}


document.addEventListener('keydown', function (e) {
	if (e.which === 27) {
		const popupActive = document.querySelector('.popup.open');
		popupClose(popupActive);
	}
});