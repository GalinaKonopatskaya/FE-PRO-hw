const userForm = document.forms['userForm'];
const submitUsForm = document.querySelector('#submitUserData');


const viewContainer = document.querySelector(".view-formlist");



submitUsForm.addEventListener('click', function (e) {
        e.preventDefault();
        const username = userForm.elements.username.value;
        const usersurname = userForm.elements.usersurname.value;
        const password = userForm.elements.userpas.value;
        const userphone = userForm.elements.userphone.value;
        const email = userForm.elements.email.value;
        const age = userForm.elements.age.value;
        const gender = userForm.elements.gender.value;

        const result = {
                gender,
                age,
                email,
                userphone,
                password,
                usersurname,
                username,
        };

        show(result);

        // const popupActive = document.querySelector('.popup.open');
        // popupClose(popupActive, false);

        //viewContainer.innerText = "text"


})


function show(resultObj) {
        viewContainer.innerHTML = "";
        for (let key in resultObj) {
                // const paragraph = document.createElement('p');
                // paragraph.innerText = `${key} - ${resultObj[key]}`;
                viewContainer.insertAdjacentHTML('afterbegin', `<p>${key} - ${resultObj[key]}</p>`);

        }

}

